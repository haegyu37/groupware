package com.groupware.wimir.constant;

public enum Authority {
    ROLE_USER, ROLE_ADMIN, ROLE_BOLCK
    //일반, 관리자, 차단
}