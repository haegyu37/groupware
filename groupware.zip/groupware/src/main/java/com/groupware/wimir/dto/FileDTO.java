package com.groupware.wimir.dto;

public class FileDTO {
    private Long id;
    private String name;
    private Long size;
    private String path;
    private Long documentId;

}
