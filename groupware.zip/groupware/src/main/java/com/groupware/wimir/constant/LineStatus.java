package com.groupware.wimir.constant;

public enum LineStatus {

    APPORVER, REFERRER
//    결재자, 참조자
}
