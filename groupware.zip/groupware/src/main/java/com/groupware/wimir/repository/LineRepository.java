package com.groupware.wimir.repository;

import com.groupware.wimir.entity.App;
import com.groupware.wimir.entity.Line;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface LineRepository extends CrudRepository <Line, Long> {

    Line findByStep(int step);

    @Override
    List<Line> findAll(); //Iterable 형식 말고 List 형식으로 받기


}
