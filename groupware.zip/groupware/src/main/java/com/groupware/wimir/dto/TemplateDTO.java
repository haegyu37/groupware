package com.groupware.wimir.dto;

import java.util.Date;

public class TemplateDTO {
    private Long id;
    private String name;
    private Date date;
    private String category;
}

