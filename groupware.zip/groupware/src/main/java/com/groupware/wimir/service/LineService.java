package com.groupware.wimir.service;

import com.groupware.wimir.entity.Line;

import java.util.List;

public interface LineService {
    List<Line> getAllLines();
    Line createLine(Line line);
    Line updateLine(Line line);
    void deleteLine(Long lineId);
    Line getLineById(Long lineId);
}
