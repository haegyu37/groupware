package com.groupware.wimir.service;

public class MemberService {
}
