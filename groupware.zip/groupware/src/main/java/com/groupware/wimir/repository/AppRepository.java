package com.groupware.wimir.repository;

import com.groupware.wimir.entity.App;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppRepository extends CrudRepository <App, Long> {

    @Override
    List<App> findAll(); //Iterable 형식 말고 List 형식으로 받기
}
